clear; close all; clc;

% Parameters
M = 16; % modulation order (M-QAM)
k = log2(M); % number of bits per symbol
numSymbols = 1000; % number of symbols
numBits = numSymbols*k; % number of bits
SNR = 20; % signal-to-noise ratio in dB
rolloff = 0.25; % RRC roll-off factor
span = 25; % RRC filter transient length
Rsamp = 100e6; % sample rate
Rsym = 10e6; % symbol rate
filter = 'yes'; % opt filter 'yes' or 'no'

%% Transmitter


% Sine signal

% Generate random binary data
 bitsIn = randi([0 1], numBits, 1);

% Reshape data into k-bit symbols for QAM modulation
dataIn = reshape(bitsIn, [], k);

% Convert binary values to decimal values (integers)
decIn = bi2de(dataIn, 'left-msb');

% QAM Modulation
symbols = qammod(decIn, M, 'gray', UnitAveragePower=true);

switch filter
    case 'yes'
        % Create RRC filter
        rrc_filt = rcosdesign(rolloff, span, Rsamp/Rsym,'sqrt');

        % up-sample
        symbolsUp = upsample(symbols, Rsamp/Rsym);

        % pulse shaping
        txSignal = conv(rrc_filt,symbolsUp);

        % separate real and imag
        txSignalRe = real(txSignal);
        txSignalIm = imag(txSignal);
        
        % convert to 1.15 fixed point
        txSignalRe_fix = dec2bin(txSignalRe * 2^13, 14);
        txSignalIm_fix = dec2bin(txSignalIm * 2^13, 14);

    case 'no'
        txSignal = symbols;
end

%% Prepare Data

data_signal_Re = zeros(size(txSignalRe_fix, 1), 1, 'int16');
data_signal_Im = zeros(size(txSignalIm_fix, 1), 1, 'int16');

for i = 1:size(txSignalRe_fix, 1)
    data_signal_Re(i) = typecast(uint16(bin2dec(txSignalRe_fix(i,:))), 'int16');
end
for i = 1:size(txSignalIm_fix, 1)
    data_signal_Im(i) = typecast(uint16(bin2dec(txSignalIm_fix(i,:))), 'int16');
end


data_send_Re = data_signal_Re;
data_send_Im = data_signal_Im;

%% Prepare Data


% Normalize to fit into the DAC range (-8192 to +8191)
% First ensure the signal is within [-1, 1] range
maxVal = max([abs(txSignalRe); abs(txSignalIm)]);
realNorm = txSignalRe / maxVal;
imagNorm = txSignalIm / maxVal;

% Scale to 14-bit two's complement range
dacBits = 14;
dacMax = 2^(dacBits - 1) - 1;  % +8191
dacMin = -2^(dacBits - 1);    % -8192

realDAC = round(realNorm * dacMax);
imagDAC = round(imagNorm * dacMax);

% Clip to ensure within DAC range
realDAC = max(min(realDAC, dacMax), dacMin);
imagDAC = max(min(imagDAC, dacMax), dacMin);




data_signal_Re = cast(realDAC, 'int16');
data_signal_Im = cast(imagDAC, 'int16');

% Ensure inputs are in int16 format
ch1 = data_signal_Re;  % Channel 1 (e.g., real part)
ch2 = data_signal_Im;  % Channel 2 (e.g., imaginary part)

% Convert to unsigned 14-bit by masking and ensuring only 14 bits are used
ch1_14 = bitand(int32(ch1), int32(2^14 - 1));  % Mask lower 14 bits

ch2_14 = bitand(int32(ch2), int32(2^14 - 1));  % Same for ch2


% Shift and combine into 32-bit word
% Format: [14-bit ch1] << 18 | [14-bit ch2] << 2
  dac_code = bitshift(ch1_14, 18) + bitshift(ch2_14, 2);


% For Constellation below:
tx_ch1_14 = bitand(bitshift(dac_code, -18), 2^14 - 1);  
tx_ch2_14 = bitand(bitshift(dac_code, -2),  2^14 - 1);  

% int16
tx_ch1 = int16(mod(tx_ch1_14 + 2^13, 2^14) - 2^13);
tx_ch2 = int16(mod(tx_ch2_14 + 2^13, 2^14) - 2^13);

% Normalization
tx_realNorm = double(tx_ch1) / 8191;
tx_imagNorm = double(tx_ch2) / 8191;

% Combine into a complex signal
tx_complex = tx_realNorm + 1i * tx_imagNorm;

%% For checking bit error rate in the DAC code formed
% rxSignal = tx_complex;
% 
% switch filter
%     case 'yes'
%         % Matched filtering
%         rxSignal = conv(rrc_filt, rxSignal);
% 
%         % Downsample
%         rxSymbols = rxSignal((span * Rsamp/Rsym) + 1 : Rsamp/Rsym : (length(symbols) + span) * Rsamp/Rsym);
% 
%     case 'no'
%         rxSymbols = rxSignal;
% end
% 
% % Scatter plot of received symbols
% scatterplot(rxSymbols)
% 
% % QAM Demodulation
% dataSymbolsOut = qamdemod(rxSymbols, M, 'gray', UnitAveragePower=true);
% 
% % Convert decimal values back to binary
% dataOutMatrix = de2bi(dataSymbolsOut, k, 'left-msb');
% 
% % Reshape binary matrix to vector
% dataOut = dataOutMatrix(:);
% 
% % Calculate number of bit errors
% numErrors = sum(bitsIn ~= dataOut);
% disp(['Number of bit errors: ' num2str(numErrors)])
% disp(['Bit error rate: ' num2str(numErrors / numBits)])


% plot
figure;
scatterplot(tx_complex);
title('Transmitted Constellation (from dac\_code)');
grid on;

TEST_BUFFER_SIZE = length(dac_code);
%TEST_BUFFER_SIZE = 4100;

% TCP Connection Setup
IP_ADDRESS = '129.16.50.14';  % <-- IP of your board
PORT = 7;                     % <-- Echo Server

% TCP connection
t = tcpclient(IP_ADDRESS, PORT);
pause(0.5);  

%% Function Selecting
disp('1 - Sending Process');
disp('2 - Receiving Process');
disp('3 - Stop Transmitting to DAC')
disp('4 - Stop Running');
running = true;
while running
    cmd = input('Enter Command 1 to 4: ');
    
    switch cmd
        case 1
            % Send length of data first
            num_samples = int32(length(dac_code));  % int16
            len_cmd = [uint8('tx00'), typecast(int32(length(dac_code)), 'uint8')];
            write(t, len_cmd, 'uint8'); 
            pause(0.1);

            %Send data
            prepare_tx_cmd = uint8('tx01');
            write(t, prepare_tx_cmd);
            
            timeout = 5;  
            start_time = tic;
            while t.NumBytesAvailable < 1
                if toc(start_time) > timeout
                    error('Timeout waiting for board response');
                end
                pause(0.1);
            end

            confirm_tx = read(t, 4, 'uint8');
            if isequal(confirm_tx, uint8('tx02'))
                 write(t, dac_code, 'int32');
                 pause(0.5);
                 disp('Sending DAC code samples finished');
            else
                 disp('Board not ready, please try again');
            end

        case 2
            % Send length of data first
            number_samples_rx = 10000;
            len_cmd_rx = [uint8('rx00'), typecast(int32(number_samples_rx), 'uint8')];
            write(t, len_cmd_rx, 'uint8'); 
            pause(0.1);

            prepare_rx_cmd = uint8('rx01');
            write(t, prepare_rx_cmd);

            % Time out is 10 seconds
            timeout = 10;
            chunk_size = 2048;  
            total_samples = number_samples_rx;

            %% Receiving real part
            received_data = zeros(total_samples, 1, 'uint32');
            received = 0;
            start_time = tic;
            disp('Waiting for data...');
            while received < total_samples
                if toc(start_time) > timeout
                    disp('Timeout waiting for data');
                    
                    break;
                end
                available_bytes = t.NumBytesAvailable;
                available_samples = floor(available_bytes / 4);
                if available_samples > 0
                    to_read = min([chunk_size, available_samples, total_samples - received]);
                    received_data(received+1 : received+to_read) = read(t, to_read, 'uint32');
                    received = received + to_read;
                end
                pause(0.1);
            end
            disp('✅ Data received');

            %% Extract real and imaginary
            rx_real_data = typecast(bitshift(received_data, -18), 'int16');
            rx_imag_data = typecast(bitshift(received_data, -2), 'int16');

            rx_real_norm = rx_real_data/dacMax;

            T = 1/Rsamp;              % Sampling period
            L = length(rx_real_norm);  % Length of signal
            t = (0:L-1)*T;         % Time vector

            plot(t, rx_real_norm);
            xlabel('Time (s)');
            ylabel('ADC normalized Value');
            title('ADC Samples vs. Time');
            grid on;

        case 3
            stop_dac_cmd = uint8('tx03');
            write(t, stop_dac_cmd);
            disp('Stop transmitting to DAC');
        
        case 4
            % Closing Program
            disp('Closing Program...');
            running = false;

        otherwise
            disp('Invalid Command');
    end
end
clear t;

%rxSignal = awgn(rxSignal_temp, SNR, 'measured');
%rxSignal = txSignal;
